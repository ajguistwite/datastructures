public class LinkedList<T> {

 /**
   Private head of list (starts out null)
  */
 private Node<T> head = null;

  /**
   * Private count of items
   */
  private int length = 0;


  /**
   * Create an empty linked list.
   */
 public LinkedList() {
 }


  /**
   * Return true if the list is empty.
   */
 public boolean isEmpty() {
  return (head == null);
 }

  /**
   * Return the number of elements in the list.
   * @return number of list elements
   */
 public int size() {
  return(length);
 }

  /**
   * Clear the list of all items
   */
 public void clear() {
  head = null;
  length = 0;
 }

  /**
   * Get an item at a position in the list
   * @param pos 1-based position in the list
   */
 public T get(int pos) {
    pos -= 1;  // API position is 1-based.

  if (pos > length || pos < 0) {
      return null;
    }
  else {
   Node<T> p = head;
   for (int i = 0; i < pos; i++) {
        if (p == null) {
          return null;
        }
        p = p.getNext();
      }
      if (p == null) {
        return null;
      }
      return p.getData();
  }
 }

  /**
   * Add an element to the list at the position provided.
   * @param item item to be added
   * @param pos 1-based position
   * @return true if the item could be added at the position provided
   */
 public boolean add(T item, int pos) {
    pos -= 1; // API position is 1-based.
  boolean answer = false;

    if ((pos > length) || (pos < 0)) {
      answer = false;
    }
    else if (head == null || pos == 0) {
   head = new Node<T>(item, head);
   length++;
   answer = true;
  } 
    else {
   Node<T> p = head;
      while(pos > 1) {
        p = p.getNext();
        pos -= 1;
      }
      p.setNext(new Node<T>(item, p.getNext()));
      length++;
      answer = true;
    }

  return answer;
 }

  /**
   * Remove the provided item from the list.
   * @param item item to be removed
   * @return true if the remove was successful.
   */
 public boolean remove(T item) {

    Node<T> p = head;
    Node<T> previous = null;
    while(p != null) {
      if (p.getData().equals(item)) {
        // found item to remove.
        if (previous == null) {
          // must be the head of the list
          head = p.getNext();
        } else {
          previous.setNext(p.getNext());
        }
        length = length - 1;
        return true;
      }
      previous = p;
      p = p.getNext();
    }
    return false;
 }

  /**
   * Return a string representation of the items in the list.
   * @return string representation of the list.
   */
 public String toString(){
    Node<T> p = head;
  String ret = "";
  while(p != null) {
      ret = ret + p.toString();
      if (p.getNext() != null) {
        ret = ret + ", ";
      }
      p = p.getNext();
    }
    return ("[" + ret + "]");
 }

  /**
   * Return true if the item provided is contained in the list.
   * The method uses the equals method of type T for comparison.
   * @param item item to look for
   * @return true if the item provided is contained in the list.
   */
 public boolean contains(T item){
  Node<T> p = head;
    while(p != null) {
      if (p.getData().equals(item)) {
        return true;
      }
      p = p.getNext();
    }
    return false;
  }
 
}

